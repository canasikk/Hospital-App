﻿namespace DopemaHastanesi
{
    partial class AdminEkrani
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminEkrani));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.bransDataGrid = new System.Windows.Forms.DataGridView();
            this.bransMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.yenileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.silToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.şuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.şuAnkiVerileriExceleAktarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.bransEkleBtn = new System.Windows.Forms.Button();
            this.bransTxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.sekreterDogumTarihiDt = new System.Windows.Forms.DateTimePicker();
            this.sekreterBabaTxt = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.sekreterEkleBtn = new System.Windows.Forms.Button();
            this.sekreterTcTxt = new System.Windows.Forms.MaskedTextBox();
            this.sekreterParolaTxt = new System.Windows.Forms.TextBox();
            this.sekreterMailTxt = new System.Windows.Forms.MaskedTextBox();
            this.sekreterCepTxt = new System.Windows.Forms.MaskedTextBox();
            this.sekreterDogumCmb = new System.Windows.Forms.ComboBox();
            this.sekreterSoyadTxt = new System.Windows.Forms.TextBox();
            this.sekreterAdTxt = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.sekreterDataGrid = new System.Windows.Forms.DataGridView();
            this.sekreterMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.yenileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.silToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.şuAnkiVerileriYazdırToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.şuAnkiVerileriExceleAktarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.sekreterAraTxt = new System.Windows.Forms.TextBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.doktorDogumDtp = new System.Windows.Forms.DateTimePicker();
            this.doktorBabaTxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.doktorEkleBtn = new System.Windows.Forms.Button();
            this.doktorTcTxt = new System.Windows.Forms.MaskedTextBox();
            this.doktorParolaTxt = new System.Windows.Forms.TextBox();
            this.doktorMailTxt = new System.Windows.Forms.MaskedTextBox();
            this.doktorCepTxt = new System.Windows.Forms.MaskedTextBox();
            this.doktorBransCmb = new System.Windows.Forms.ComboBox();
            this.doktorDogumCmb = new System.Windows.Forms.ComboBox();
            this.doktorSoyadTxt = new System.Windows.Forms.TextBox();
            this.doktorAdTxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.doktorDataGrid = new System.Windows.Forms.DataGridView();
            this.doktorMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.şuAnkiVerileriYazdırToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.şuAnkiVerileriExceleAktarToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.doktorBransAraTxt = new System.Windows.Forms.TextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.doktorTcAraTxt = new System.Windows.Forms.TextBox();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printDocument2 = new System.Drawing.Printing.PrintDocument();
            this.printDocument3 = new System.Drawing.Printing.PrintDocument();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bransDataGrid)).BeginInit();
            this.bransMenu.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sekreterDataGrid)).BeginInit();
            this.sekreterMenu.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.doktorDataGrid)).BeginInit();
            this.doktorMenu.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(920, 452);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(912, 423);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Branş Ekle";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.bransDataGrid);
            this.groupBox4.Location = new System.Drawing.Point(4, 64);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(900, 354);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Branş Kayıtları";
            // 
            // bransDataGrid
            // 
            this.bransDataGrid.AllowUserToAddRows = false;
            this.bransDataGrid.AllowUserToDeleteRows = false;
            this.bransDataGrid.AllowUserToResizeRows = false;
            this.bransDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bransDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bransDataGrid.ColumnHeadersVisible = false;
            this.bransDataGrid.ContextMenuStrip = this.bransMenu;
            this.bransDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bransDataGrid.Location = new System.Drawing.Point(3, 16);
            this.bransDataGrid.Name = "bransDataGrid";
            this.bransDataGrid.RowHeadersVisible = false;
            this.bransDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bransDataGrid.Size = new System.Drawing.Size(894, 335);
            this.bransDataGrid.TabIndex = 1;
            this.bransDataGrid.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.bransDataGrid_CellValueChanged);
            // 
            // bransMenu
            // 
            this.bransMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yenileToolStripMenuItem,
            this.toolStripSeparator1,
            this.silToolStripMenuItem,
            this.toolStripSeparator4,
            this.şuToolStripMenuItem,
            this.toolStripSeparator5,
            this.şuAnkiVerileriExceleAktarToolStripMenuItem});
            this.bransMenu.Name = "bransMenu";
            this.bransMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.bransMenu.Size = new System.Drawing.Size(221, 110);
            // 
            // yenileToolStripMenuItem
            // 
            this.yenileToolStripMenuItem.Name = "yenileToolStripMenuItem";
            this.yenileToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.yenileToolStripMenuItem.Text = "Yenile";
            this.yenileToolStripMenuItem.Click += new System.EventHandler(this.yenileToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(217, 6);
            // 
            // silToolStripMenuItem
            // 
            this.silToolStripMenuItem.Name = "silToolStripMenuItem";
            this.silToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.silToolStripMenuItem.Text = "Sil";
            this.silToolStripMenuItem.Click += new System.EventHandler(this.silToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(217, 6);
            // 
            // şuToolStripMenuItem
            // 
            this.şuToolStripMenuItem.Name = "şuToolStripMenuItem";
            this.şuToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.şuToolStripMenuItem.Text = "Şu anki verileri Yazdır";
            this.şuToolStripMenuItem.Click += new System.EventHandler(this.şuToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(217, 6);
            // 
            // şuAnkiVerileriExceleAktarToolStripMenuItem
            // 
            this.şuAnkiVerileriExceleAktarToolStripMenuItem.Name = "şuAnkiVerileriExceleAktarToolStripMenuItem";
            this.şuAnkiVerileriExceleAktarToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.şuAnkiVerileriExceleAktarToolStripMenuItem.Text = "Şu anki verileri Excel\'e Aktar";
            this.şuAnkiVerileriExceleAktarToolStripMenuItem.Click += new System.EventHandler(this.şuAnkiVerileriExceleAktarToolStripMenuItem_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.bransEkleBtn);
            this.groupBox3.Controls.Add(this.bransTxt);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(4, 7);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(900, 52);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Branş Ekle";
            // 
            // bransEkleBtn
            // 
            this.bransEkleBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bransEkleBtn.Location = new System.Drawing.Point(722, 15);
            this.bransEkleBtn.Name = "bransEkleBtn";
            this.bransEkleBtn.Size = new System.Drawing.Size(172, 23);
            this.bransEkleBtn.TabIndex = 2;
            this.bransEkleBtn.Text = "Ekle";
            this.bransEkleBtn.UseVisualStyleBackColor = true;
            this.bransEkleBtn.Click += new System.EventHandler(this.bransEkleBtn_Click);
            // 
            // bransTxt
            // 
            this.bransTxt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bransTxt.Location = new System.Drawing.Point(74, 17);
            this.bransTxt.Name = "bransTxt";
            this.bransTxt.Size = new System.Drawing.Size(638, 20);
            this.bransTxt.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Branş Adı : ";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(912, 423);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Sekreter Ekle";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.sekreterDogumTarihiDt);
            this.groupBox5.Controls.Add(this.sekreterBabaTxt);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.sekreterEkleBtn);
            this.groupBox5.Controls.Add(this.sekreterTcTxt);
            this.groupBox5.Controls.Add(this.sekreterParolaTxt);
            this.groupBox5.Controls.Add(this.sekreterMailTxt);
            this.groupBox5.Controls.Add(this.sekreterCepTxt);
            this.groupBox5.Controls.Add(this.sekreterDogumCmb);
            this.groupBox5.Controls.Add(this.sekreterSoyadTxt);
            this.groupBox5.Controls.Add(this.sekreterAdTxt);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.label22);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Location = new System.Drawing.Point(189, 41);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(529, 332);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Sekreter Ekle";
            // 
            // sekreterDogumTarihiDt
            // 
            this.sekreterDogumTarihiDt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sekreterDogumTarihiDt.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.sekreterDogumTarihiDt.Location = new System.Drawing.Point(158, 179);
            this.sekreterDogumTarihiDt.MaxDate = new System.DateTime(2030, 12, 31, 0, 0, 0, 0);
            this.sekreterDogumTarihiDt.MinDate = new System.DateTime(1940, 1, 1, 0, 0, 0, 0);
            this.sekreterDogumTarihiDt.Name = "sekreterDogumTarihiDt";
            this.sekreterDogumTarihiDt.Size = new System.Drawing.Size(320, 20);
            this.sekreterDogumTarihiDt.TabIndex = 5;
            // 
            // sekreterBabaTxt
            // 
            this.sekreterBabaTxt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sekreterBabaTxt.Location = new System.Drawing.Point(158, 123);
            this.sekreterBabaTxt.MaxLength = 25;
            this.sekreterBabaTxt.Name = "sekreterBabaTxt";
            this.sekreterBabaTxt.Size = new System.Drawing.Size(320, 20);
            this.sekreterBabaTxt.TabIndex = 3;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(98, 126);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(56, 13);
            this.label16.TabIndex = 108;
            this.label16.Text = "Baba Adı :";
            // 
            // sekreterEkleBtn
            // 
            this.sekreterEkleBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.sekreterEkleBtn.Location = new System.Drawing.Point(369, 290);
            this.sekreterEkleBtn.Name = "sekreterEkleBtn";
            this.sekreterEkleBtn.Size = new System.Drawing.Size(109, 23);
            this.sekreterEkleBtn.TabIndex = 9;
            this.sekreterEkleBtn.Text = "Ekle";
            this.sekreterEkleBtn.UseVisualStyleBackColor = true;
            this.sekreterEkleBtn.Click += new System.EventHandler(this.sekreterEkleBtn_Click);
            // 
            // sekreterTcTxt
            // 
            this.sekreterTcTxt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sekreterTcTxt.Location = new System.Drawing.Point(158, 39);
            this.sekreterTcTxt.Mask = "00000000000";
            this.sekreterTcTxt.Name = "sekreterTcTxt";
            this.sekreterTcTxt.Size = new System.Drawing.Size(320, 20);
            this.sekreterTcTxt.TabIndex = 0;
            this.sekreterTcTxt.ValidatingType = typeof(int);
            // 
            // sekreterParolaTxt
            // 
            this.sekreterParolaTxt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sekreterParolaTxt.Location = new System.Drawing.Point(158, 264);
            this.sekreterParolaTxt.Name = "sekreterParolaTxt";
            this.sekreterParolaTxt.Size = new System.Drawing.Size(320, 20);
            this.sekreterParolaTxt.TabIndex = 8;
            // 
            // sekreterMailTxt
            // 
            this.sekreterMailTxt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sekreterMailTxt.Location = new System.Drawing.Point(158, 236);
            this.sekreterMailTxt.Name = "sekreterMailTxt";
            this.sekreterMailTxt.Size = new System.Drawing.Size(320, 20);
            this.sekreterMailTxt.TabIndex = 7;
            // 
            // sekreterCepTxt
            // 
            this.sekreterCepTxt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sekreterCepTxt.Location = new System.Drawing.Point(158, 208);
            this.sekreterCepTxt.Mask = "(999) 000-0000";
            this.sekreterCepTxt.Name = "sekreterCepTxt";
            this.sekreterCepTxt.Size = new System.Drawing.Size(320, 20);
            this.sekreterCepTxt.TabIndex = 6;
            // 
            // sekreterDogumCmb
            // 
            this.sekreterDogumCmb.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sekreterDogumCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.sekreterDogumCmb.FormattingEnabled = true;
            this.sekreterDogumCmb.Items.AddRange(new object[] {
            "DİĞER",
            "Adana",
            "Adıyaman",
            "Afyonkarahisar",
            "Ağrı",
            "Aksaray",
            "Amasya",
            "Ankara",
            "Antalya",
            "Ardahan",
            "Artvin",
            "Aydın",
            "Balıkesir",
            "Bartın",
            "Batman",
            "Bayburt",
            "Bilecik",
            "Bingöl",
            "Bitlis",
            "Bolu",
            "Burdur",
            "Bursa",
            "Çanakkale",
            "Çankırı",
            "Çorum",
            "Denizli",
            "Diyarbakır",
            "Düzce",
            "Edirne",
            "Elazığ",
            "Erzincan",
            "Erzurum",
            "Eskişehir",
            "Gaziantep",
            "Giresun",
            "Gümüşhane",
            "Hakkâri",
            "Hatay",
            "Iğdır",
            "Isparta",
            "İstanbul",
            "İzmir",
            "Kahramanmaraş",
            "Karabük",
            "Karaman",
            "Kars",
            "Kastamonu",
            "Kayseri",
            "Kilis",
            "Kırıkkale",
            "Kırklareli",
            "Kırşehir",
            "Kocaeli",
            "Konya",
            "Kütahya",
            "Malatya",
            "Manisa",
            "Mardin",
            "Mersin",
            "Muğla",
            "Muş",
            "Nevşehir",
            "Niğde",
            "Ordu",
            "Osmaniye",
            "Rize",
            "Sakarya",
            "Samsun",
            "Şanlıurfa",
            "Siirt",
            "Sinop",
            "Sivas",
            "Şırnak",
            "Tekirdağ",
            "Tokat",
            "Trabzon",
            "Tunceli",
            "Uşak",
            "Van",
            "Yalova",
            "Yozgat",
            "Zonguldak"});
            this.sekreterDogumCmb.Location = new System.Drawing.Point(158, 151);
            this.sekreterDogumCmb.Name = "sekreterDogumCmb";
            this.sekreterDogumCmb.Size = new System.Drawing.Size(320, 21);
            this.sekreterDogumCmb.TabIndex = 4;
            // 
            // sekreterSoyadTxt
            // 
            this.sekreterSoyadTxt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sekreterSoyadTxt.Location = new System.Drawing.Point(158, 95);
            this.sekreterSoyadTxt.MaxLength = 25;
            this.sekreterSoyadTxt.Name = "sekreterSoyadTxt";
            this.sekreterSoyadTxt.Size = new System.Drawing.Size(320, 20);
            this.sekreterSoyadTxt.TabIndex = 2;
            // 
            // sekreterAdTxt
            // 
            this.sekreterAdTxt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sekreterAdTxt.Location = new System.Drawing.Point(158, 67);
            this.sekreterAdTxt.MaxLength = 10;
            this.sekreterAdTxt.Name = "sekreterAdTxt";
            this.sekreterAdTxt.Size = new System.Drawing.Size(320, 20);
            this.sekreterAdTxt.TabIndex = 1;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(108, 267);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(46, 13);
            this.label18.TabIndex = 103;
            this.label18.Text = "Parola : ";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(101, 239);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 13);
            this.label19.TabIndex = 102;
            this.label19.Text = "E-Posta : ";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(74, 211);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(80, 13);
            this.label20.TabIndex = 100;
            this.label20.Text = "Cep Telefonu : ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(75, 183);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(79, 13);
            this.label22.TabIndex = 97;
            this.label22.Text = "Doğum Tarihi : ";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(83, 154);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(71, 13);
            this.label23.TabIndex = 96;
            this.label23.Text = "Doğum Yeri : ";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(108, 98);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(49, 13);
            this.label24.TabIndex = 93;
            this.label24.Text = "Soyad :  ";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(125, 70);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 13);
            this.label25.TabIndex = 92;
            this.label25.Text = "Ad : ";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(50, 42);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(104, 13);
            this.label26.TabIndex = 89;
            this.label26.Text = "TC Kimlik Numarası :";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox6);
            this.tabPage4.Controls.Add(this.groupBox7);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(912, 423);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Sekreter Düzenle && Sil";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox6.Controls.Add(this.sekreterDataGrid);
            this.groupBox6.Location = new System.Drawing.Point(6, 66);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(900, 354);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Sekreter Kayıtları";
            // 
            // sekreterDataGrid
            // 
            this.sekreterDataGrid.AllowUserToAddRows = false;
            this.sekreterDataGrid.AllowUserToDeleteRows = false;
            this.sekreterDataGrid.AllowUserToResizeRows = false;
            this.sekreterDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.sekreterDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sekreterDataGrid.ColumnHeadersVisible = false;
            this.sekreterDataGrid.ContextMenuStrip = this.sekreterMenu;
            this.sekreterDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sekreterDataGrid.Location = new System.Drawing.Point(3, 16);
            this.sekreterDataGrid.Name = "sekreterDataGrid";
            this.sekreterDataGrid.RowHeadersVisible = false;
            this.sekreterDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.sekreterDataGrid.Size = new System.Drawing.Size(894, 335);
            this.sekreterDataGrid.TabIndex = 1;
            this.sekreterDataGrid.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.sekreterDataGrid_CellValueChanged);
            // 
            // sekreterMenu
            // 
            this.sekreterMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yenileToolStripMenuItem1,
            this.toolStripSeparator2,
            this.silToolStripMenuItem1,
            this.toolStripSeparator7,
            this.şuAnkiVerileriYazdırToolStripMenuItem,
            this.toolStripSeparator6,
            this.şuAnkiVerileriExceleAktarToolStripMenuItem1});
            this.sekreterMenu.Name = "sekreterMenu";
            this.sekreterMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.sekreterMenu.Size = new System.Drawing.Size(221, 110);
            // 
            // yenileToolStripMenuItem1
            // 
            this.yenileToolStripMenuItem1.Name = "yenileToolStripMenuItem1";
            this.yenileToolStripMenuItem1.Size = new System.Drawing.Size(220, 22);
            this.yenileToolStripMenuItem1.Text = "Yenile";
            this.yenileToolStripMenuItem1.Click += new System.EventHandler(this.yenileToolStripMenuItem1_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(217, 6);
            // 
            // silToolStripMenuItem1
            // 
            this.silToolStripMenuItem1.Name = "silToolStripMenuItem1";
            this.silToolStripMenuItem1.Size = new System.Drawing.Size(220, 22);
            this.silToolStripMenuItem1.Text = "Sil";
            this.silToolStripMenuItem1.Click += new System.EventHandler(this.silToolStripMenuItem1_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(217, 6);
            // 
            // şuAnkiVerileriYazdırToolStripMenuItem
            // 
            this.şuAnkiVerileriYazdırToolStripMenuItem.Name = "şuAnkiVerileriYazdırToolStripMenuItem";
            this.şuAnkiVerileriYazdırToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.şuAnkiVerileriYazdırToolStripMenuItem.Text = "Şu anki verileri Yazdır";
            this.şuAnkiVerileriYazdırToolStripMenuItem.Click += new System.EventHandler(this.şuAnkiVerileriYazdırToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(217, 6);
            // 
            // şuAnkiVerileriExceleAktarToolStripMenuItem1
            // 
            this.şuAnkiVerileriExceleAktarToolStripMenuItem1.Name = "şuAnkiVerileriExceleAktarToolStripMenuItem1";
            this.şuAnkiVerileriExceleAktarToolStripMenuItem1.Size = new System.Drawing.Size(220, 22);
            this.şuAnkiVerileriExceleAktarToolStripMenuItem1.Text = "Şu anki verileri Excel\'e Aktar";
            this.şuAnkiVerileriExceleAktarToolStripMenuItem1.Click += new System.EventHandler(this.şuAnkiVerileriExceleAktarToolStripMenuItem1_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox7.Controls.Add(this.sekreterAraTxt);
            this.groupBox7.Location = new System.Drawing.Point(6, 7);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(900, 52);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "TC\'ye Göre Ara";
            // 
            // sekreterAraTxt
            // 
            this.sekreterAraTxt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sekreterAraTxt.Location = new System.Drawing.Point(7, 20);
            this.sekreterAraTxt.MaxLength = 11;
            this.sekreterAraTxt.Name = "sekreterAraTxt";
            this.sekreterAraTxt.Size = new System.Drawing.Size(887, 20);
            this.sekreterAraTxt.TabIndex = 0;
            this.sekreterAraTxt.TextChanged += new System.EventHandler(this.sekreterAraTxt_TextChanged);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox8);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(912, 423);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Doktor Ekle";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox8.Controls.Add(this.doktorDogumDtp);
            this.groupBox8.Controls.Add(this.doktorBabaTxt);
            this.groupBox8.Controls.Add(this.label2);
            this.groupBox8.Controls.Add(this.doktorEkleBtn);
            this.groupBox8.Controls.Add(this.doktorTcTxt);
            this.groupBox8.Controls.Add(this.doktorParolaTxt);
            this.groupBox8.Controls.Add(this.doktorMailTxt);
            this.groupBox8.Controls.Add(this.doktorCepTxt);
            this.groupBox8.Controls.Add(this.doktorBransCmb);
            this.groupBox8.Controls.Add(this.doktorDogumCmb);
            this.groupBox8.Controls.Add(this.doktorSoyadTxt);
            this.groupBox8.Controls.Add(this.doktorAdTxt);
            this.groupBox8.Controls.Add(this.label3);
            this.groupBox8.Controls.Add(this.label4);
            this.groupBox8.Controls.Add(this.label5);
            this.groupBox8.Controls.Add(this.label11);
            this.groupBox8.Controls.Add(this.label6);
            this.groupBox8.Controls.Add(this.label7);
            this.groupBox8.Controls.Add(this.label8);
            this.groupBox8.Controls.Add(this.label9);
            this.groupBox8.Controls.Add(this.label10);
            this.groupBox8.Location = new System.Drawing.Point(192, 42);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(529, 359);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Doktor Ekle";
            // 
            // doktorDogumDtp
            // 
            this.doktorDogumDtp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.doktorDogumDtp.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.doktorDogumDtp.Location = new System.Drawing.Point(158, 175);
            this.doktorDogumDtp.MaxDate = new System.DateTime(2030, 12, 31, 0, 0, 0, 0);
            this.doktorDogumDtp.MinDate = new System.DateTime(1940, 1, 1, 0, 0, 0, 0);
            this.doktorDogumDtp.Name = "doktorDogumDtp";
            this.doktorDogumDtp.Size = new System.Drawing.Size(320, 20);
            this.doktorDogumDtp.TabIndex = 5;
            // 
            // doktorBabaTxt
            // 
            this.doktorBabaTxt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.doktorBabaTxt.Location = new System.Drawing.Point(158, 120);
            this.doktorBabaTxt.MaxLength = 25;
            this.doktorBabaTxt.Name = "doktorBabaTxt";
            this.doktorBabaTxt.Size = new System.Drawing.Size(320, 20);
            this.doktorBabaTxt.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(95, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 108;
            this.label2.Text = "Baba Adı :";
            // 
            // doktorEkleBtn
            // 
            this.doktorEkleBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.doktorEkleBtn.Location = new System.Drawing.Point(369, 314);
            this.doktorEkleBtn.Name = "doktorEkleBtn";
            this.doktorEkleBtn.Size = new System.Drawing.Size(109, 23);
            this.doktorEkleBtn.TabIndex = 10;
            this.doktorEkleBtn.Text = "Ekle";
            this.doktorEkleBtn.UseVisualStyleBackColor = true;
            this.doktorEkleBtn.Click += new System.EventHandler(this.doktorEkleBtn_Click);
            // 
            // doktorTcTxt
            // 
            this.doktorTcTxt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.doktorTcTxt.Location = new System.Drawing.Point(158, 39);
            this.doktorTcTxt.Mask = "00000000000";
            this.doktorTcTxt.Name = "doktorTcTxt";
            this.doktorTcTxt.Size = new System.Drawing.Size(320, 20);
            this.doktorTcTxt.TabIndex = 0;
            this.doktorTcTxt.ValidatingType = typeof(int);
            // 
            // doktorParolaTxt
            // 
            this.doktorParolaTxt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.doktorParolaTxt.Location = new System.Drawing.Point(158, 284);
            this.doktorParolaTxt.Name = "doktorParolaTxt";
            this.doktorParolaTxt.Size = new System.Drawing.Size(320, 20);
            this.doktorParolaTxt.TabIndex = 9;
            // 
            // doktorMailTxt
            // 
            this.doktorMailTxt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.doktorMailTxt.Location = new System.Drawing.Point(158, 257);
            this.doktorMailTxt.Name = "doktorMailTxt";
            this.doktorMailTxt.Size = new System.Drawing.Size(320, 20);
            this.doktorMailTxt.TabIndex = 8;
            // 
            // doktorCepTxt
            // 
            this.doktorCepTxt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.doktorCepTxt.Location = new System.Drawing.Point(158, 230);
            this.doktorCepTxt.Mask = "(999) 000-0000";
            this.doktorCepTxt.Name = "doktorCepTxt";
            this.doktorCepTxt.Size = new System.Drawing.Size(320, 20);
            this.doktorCepTxt.TabIndex = 7;
            // 
            // doktorBransCmb
            // 
            this.doktorBransCmb.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.doktorBransCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.doktorBransCmb.FormattingEnabled = true;
            this.doktorBransCmb.Location = new System.Drawing.Point(158, 202);
            this.doktorBransCmb.Name = "doktorBransCmb";
            this.doktorBransCmb.Size = new System.Drawing.Size(320, 21);
            this.doktorBransCmb.TabIndex = 6;
            // 
            // doktorDogumCmb
            // 
            this.doktorDogumCmb.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.doktorDogumCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.doktorDogumCmb.FormattingEnabled = true;
            this.doktorDogumCmb.Items.AddRange(new object[] {
            "DİĞER",
            "Adana",
            "Adıyaman",
            "Afyonkarahisar",
            "Ağrı",
            "Aksaray",
            "Amasya",
            "Ankara",
            "Antalya",
            "Ardahan",
            "Artvin",
            "Aydın",
            "Balıkesir",
            "Bartın",
            "Batman",
            "Bayburt",
            "Bilecik",
            "Bingöl",
            "Bitlis",
            "Bolu",
            "Burdur",
            "Bursa",
            "Çanakkale",
            "Çankırı",
            "Çorum",
            "Denizli",
            "Diyarbakır",
            "Düzce",
            "Edirne",
            "Elazığ",
            "Erzincan",
            "Erzurum",
            "Eskişehir",
            "Gaziantep",
            "Giresun",
            "Gümüşhane",
            "Hakkâri",
            "Hatay",
            "Iğdır",
            "Isparta",
            "İstanbul",
            "İzmir",
            "Kahramanmaraş",
            "Karabük",
            "Karaman",
            "Kars",
            "Kastamonu",
            "Kayseri",
            "Kilis",
            "Kırıkkale",
            "Kırklareli",
            "Kırşehir",
            "Kocaeli",
            "Konya",
            "Kütahya",
            "Malatya",
            "Manisa",
            "Mardin",
            "Mersin",
            "Muğla",
            "Muş",
            "Nevşehir",
            "Niğde",
            "Ordu",
            "Osmaniye",
            "Rize",
            "Sakarya",
            "Samsun",
            "Şanlıurfa",
            "Siirt",
            "Sinop",
            "Sivas",
            "Şırnak",
            "Tekirdağ",
            "Tokat",
            "Trabzon",
            "Tunceli",
            "Uşak",
            "Van",
            "Yalova",
            "Yozgat",
            "Zonguldak"});
            this.doktorDogumCmb.Location = new System.Drawing.Point(158, 147);
            this.doktorDogumCmb.Name = "doktorDogumCmb";
            this.doktorDogumCmb.Size = new System.Drawing.Size(320, 21);
            this.doktorDogumCmb.TabIndex = 4;
            // 
            // doktorSoyadTxt
            // 
            this.doktorSoyadTxt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.doktorSoyadTxt.Location = new System.Drawing.Point(158, 93);
            this.doktorSoyadTxt.MaxLength = 25;
            this.doktorSoyadTxt.Name = "doktorSoyadTxt";
            this.doktorSoyadTxt.Size = new System.Drawing.Size(320, 20);
            this.doktorSoyadTxt.TabIndex = 2;
            // 
            // doktorAdTxt
            // 
            this.doktorAdTxt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.doktorAdTxt.Location = new System.Drawing.Point(158, 66);
            this.doktorAdTxt.MaxLength = 10;
            this.doktorAdTxt.Name = "doktorAdTxt";
            this.doktorAdTxt.Size = new System.Drawing.Size(320, 20);
            this.doktorAdTxt.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(105, 287);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 103;
            this.label3.Text = "Parola : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(98, 260);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 102;
            this.label4.Text = "E-Posta : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(71, 233);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 13);
            this.label5.TabIndex = 100;
            this.label5.Text = "Cep Telefonu : ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(111, 205);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(40, 13);
            this.label11.TabIndex = 97;
            this.label11.Text = "Branş :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(72, 181);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 97;
            this.label6.Text = "Doğum Tarihi : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(80, 150);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 13);
            this.label7.TabIndex = 96;
            this.label7.Text = "Doğum Yeri : ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(106, 96);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 13);
            this.label8.TabIndex = 93;
            this.label8.Text = "Soyad : ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(122, 69);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 13);
            this.label9.TabIndex = 92;
            this.label9.Text = "Ad : ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(47, 42);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(104, 13);
            this.label10.TabIndex = 89;
            this.label10.Text = "TC Kimlik Numarası :";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.groupBox9);
            this.tabPage6.Controls.Add(this.groupBox11);
            this.tabPage6.Controls.Add(this.groupBox10);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(912, 423);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Doktor Düzenle && Sil";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox9.Controls.Add(this.doktorDataGrid);
            this.groupBox9.Location = new System.Drawing.Point(6, 66);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(900, 354);
            this.groupBox9.TabIndex = 3;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Doktor Kayıtları";
            // 
            // doktorDataGrid
            // 
            this.doktorDataGrid.AllowUserToAddRows = false;
            this.doktorDataGrid.AllowUserToDeleteRows = false;
            this.doktorDataGrid.AllowUserToResizeRows = false;
            this.doktorDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.doktorDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.doktorDataGrid.ColumnHeadersVisible = false;
            this.doktorDataGrid.ContextMenuStrip = this.doktorMenu;
            this.doktorDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.doktorDataGrid.Location = new System.Drawing.Point(3, 16);
            this.doktorDataGrid.Name = "doktorDataGrid";
            this.doktorDataGrid.RowHeadersVisible = false;
            this.doktorDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.doktorDataGrid.Size = new System.Drawing.Size(894, 335);
            this.doktorDataGrid.TabIndex = 1;
            this.doktorDataGrid.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.doktorDataGrid_CellValueChanged);
            // 
            // doktorMenu
            // 
            this.doktorMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripSeparator3,
            this.toolStripMenuItem2,
            this.toolStripSeparator9,
            this.şuAnkiVerileriYazdırToolStripMenuItem1,
            this.toolStripSeparator8,
            this.şuAnkiVerileriExceleAktarToolStripMenuItem2});
            this.doktorMenu.Name = "sekreterMenu";
            this.doktorMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.doktorMenu.Size = new System.Drawing.Size(221, 110);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(220, 22);
            this.toolStripMenuItem1.Text = "Yenile";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(217, 6);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(220, 22);
            this.toolStripMenuItem2.Text = "Sil";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(217, 6);
            // 
            // şuAnkiVerileriYazdırToolStripMenuItem1
            // 
            this.şuAnkiVerileriYazdırToolStripMenuItem1.Name = "şuAnkiVerileriYazdırToolStripMenuItem1";
            this.şuAnkiVerileriYazdırToolStripMenuItem1.Size = new System.Drawing.Size(220, 22);
            this.şuAnkiVerileriYazdırToolStripMenuItem1.Text = "Şu anki verileri Yazdır";
            this.şuAnkiVerileriYazdırToolStripMenuItem1.Click += new System.EventHandler(this.şuAnkiVerileriYazdırToolStripMenuItem1_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(217, 6);
            // 
            // şuAnkiVerileriExceleAktarToolStripMenuItem2
            // 
            this.şuAnkiVerileriExceleAktarToolStripMenuItem2.Name = "şuAnkiVerileriExceleAktarToolStripMenuItem2";
            this.şuAnkiVerileriExceleAktarToolStripMenuItem2.Size = new System.Drawing.Size(220, 22);
            this.şuAnkiVerileriExceleAktarToolStripMenuItem2.Text = "Şu anki verileri Excel\'e Aktar";
            this.şuAnkiVerileriExceleAktarToolStripMenuItem2.Click += new System.EventHandler(this.şuAnkiVerileriExceleAktarToolStripMenuItem2_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.doktorBransAraTxt);
            this.groupBox11.Location = new System.Drawing.Point(206, 8);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(194, 52);
            this.groupBox11.TabIndex = 2;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Branş\'a Göre Ara";
            // 
            // doktorBransAraTxt
            // 
            this.doktorBransAraTxt.Location = new System.Drawing.Point(7, 20);
            this.doktorBransAraTxt.MaxLength = 25;
            this.doktorBransAraTxt.Name = "doktorBransAraTxt";
            this.doktorBransAraTxt.Size = new System.Drawing.Size(181, 20);
            this.doktorBransAraTxt.TabIndex = 0;
            this.doktorBransAraTxt.Click += new System.EventHandler(this.doktorBransAraTxt_Click);
            this.doktorBransAraTxt.TextChanged += new System.EventHandler(this.doktorBransAraTxt_TextChanged);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.doktorTcAraTxt);
            this.groupBox10.Location = new System.Drawing.Point(6, 7);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(194, 52);
            this.groupBox10.TabIndex = 2;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "TC\'ye Göre Ara";
            // 
            // doktorTcAraTxt
            // 
            this.doktorTcAraTxt.Location = new System.Drawing.Point(7, 20);
            this.doktorTcAraTxt.MaxLength = 11;
            this.doktorTcAraTxt.Name = "doktorTcAraTxt";
            this.doktorTcAraTxt.Size = new System.Drawing.Size(181, 20);
            this.doktorTcAraTxt.TabIndex = 0;
            this.doktorTcAraTxt.Click += new System.EventHandler(this.doktorTcAraTxt_Click);
            this.doktorTcAraTxt.TextChanged += new System.EventHandler(this.doktorTcAraTxt_TextChanged);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printDocument2
            // 
            this.printDocument2.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument2_PrintPage);
            // 
            // printDocument3
            // 
            this.printDocument3.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument3_PrintPage);
            // 
            // AdminEkrani
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(920, 452);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(936, 491);
            this.Name = "AdminEkrani";
            this.Text = "Admin Paneli";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AdminEkrani_FormClosing);
            this.Load += new System.EventHandler(this.AdminEkrani_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bransDataGrid)).EndInit();
            this.bransMenu.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sekreterDataGrid)).EndInit();
            this.sekreterMenu.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.doktorDataGrid)).EndInit();
            this.doktorMenu.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView bransDataGrid;
        private System.Windows.Forms.Button bransEkleBtn;
        private System.Windows.Forms.TextBox bransTxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DateTimePicker sekreterDogumTarihiDt;
        private System.Windows.Forms.TextBox sekreterBabaTxt;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button sekreterEkleBtn;
        private System.Windows.Forms.MaskedTextBox sekreterTcTxt;
        private System.Windows.Forms.TextBox sekreterParolaTxt;
        private System.Windows.Forms.MaskedTextBox sekreterMailTxt;
        private System.Windows.Forms.MaskedTextBox sekreterCepTxt;
        private System.Windows.Forms.ComboBox sekreterDogumCmb;
        private System.Windows.Forms.TextBox sekreterSoyadTxt;
        private System.Windows.Forms.TextBox sekreterAdTxt;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.DataGridView sekreterDataGrid;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox sekreterAraTxt;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.DateTimePicker doktorDogumDtp;
        private System.Windows.Forms.TextBox doktorBabaTxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button doktorEkleBtn;
        private System.Windows.Forms.MaskedTextBox doktorTcTxt;
        private System.Windows.Forms.TextBox doktorParolaTxt;
        private System.Windows.Forms.MaskedTextBox doktorMailTxt;
        private System.Windows.Forms.MaskedTextBox doktorCepTxt;
        private System.Windows.Forms.ComboBox doktorBransCmb;
        private System.Windows.Forms.ComboBox doktorDogumCmb;
        private System.Windows.Forms.TextBox doktorSoyadTxt;
        private System.Windows.Forms.TextBox doktorAdTxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.DataGridView doktorDataGrid;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox doktorBransAraTxt;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox doktorTcAraTxt;
        private System.Windows.Forms.ContextMenuStrip bransMenu;
        private System.Windows.Forms.ToolStripMenuItem yenileToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem silToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip sekreterMenu;
        private System.Windows.Forms.ToolStripMenuItem yenileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem silToolStripMenuItem1;
        private System.Windows.Forms.ContextMenuStrip doktorMenu;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem şuToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem şuAnkiVerileriExceleAktarToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem şuAnkiVerileriYazdırToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem şuAnkiVerileriExceleAktarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem şuAnkiVerileriYazdırToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem şuAnkiVerileriExceleAktarToolStripMenuItem2;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Drawing.Printing.PrintDocument printDocument2;
        private System.Drawing.Printing.PrintDocument printDocument3;
    }
}